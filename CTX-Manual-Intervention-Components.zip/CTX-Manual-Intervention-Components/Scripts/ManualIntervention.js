
function uiSelection(x) {
    var uiReq = x.parentElement.cells[6].outerText;
	if (uiReq.indexOf('UI') !== -1) {
		var nextPage = x.parentElement.cells[0].innerHTML;
		var tb = getElementById("ctl00_ctl00_cphMain_cphMacTool_HIDDEN");
		tb.value = nextPage;
		var textboxInput = document.getElementsByName("ctl00$ctl00$cphMain$cphMacTool$TEXTBOX")[0];
		if (typeof textboxInput !== "undefined") {
			// Clear the object value
			textboxInput.value = "";
		}
		// Delete timeout if exists
		if (typeof timeoutVar !== 'undefined') {
			clearTimeout(timeoutVar);
			delete timeoutVar;
		}
		else {
			console.log("No timeout variable");  
		}
		// Clear JSON
		window.localStorage.removeItem('stageData');
		// Continue
		WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions("ctl00$ctl00$cphMain$cphMacTool$UI", "", true, "", "", false, true));
	}
}

function DashboardBoxClick() {
  var x = event.clientX, y = event.clientY,
  elementMouseIsOver = document.elementFromPoint(x, y);
  boxText = elementMouseIsOver.parentElement.getElementsByClassName("dashboardText")[0];
  getElementById('ctl00_ctl00_cphMain_cphMacTool_DASHBOARDCLICKEDBOX').value = boxText.innerHTML;
    __doPostBack('ctl00$ctl00$cphMain$cphMacTool$CONTINUE','');
}

function BreadcrumbClick() {
  var a = event.clientX, b = event.clientY,
  elementMouseIsOver = document.elementFromPoint(a, b);
  var textboxInput = document.getElementsByName("ctl00$ctl00$cphMain$cphMacTool$TEXTBOX")[0];
  if (typeof textboxInput !== "undefined") {
	 // Clear the object value
	 textboxInput.value = "";
  }
  // Delete the cached Stage JSON Data
  window.localStorage.removeItem('stageData');
  
  // Delete timeout if exists
  if (typeof timeoutVar !== 'undefined') {
  	clearTimeout(timeoutVar);
  	delete timeoutVar;
  }
  else {
	console.log("No timeout variable");  
  }
  // Continue
  getElementById('ctl00_ctl00_cphMain_cphMacTool_DASHBOARDCLICKEDBOX').value = elementMouseIsOver.innerText;
  __doPostBack('ctl00$ctl00$cphMain$cphMacTool$CONTINUE','');

}

function RefreshClick() {
  var a = event.clientX, b = event.clientY,
  elementMouseIsOver = document.elementFromPoint(a, b);
  var textboxInput = document.getElementsByName("ctl00$ctl00$cphMain$cphMacTool$TEXTBOX")[0];
  if (typeof textboxInput !== "undefined") {
	 // Clear the object value
	 textboxInput.value = "";
  }
  // Delete the cached Stage JSON Data
  window.localStorage.removeItem('stageData');
  
  // Delete timeout if exists
  if (typeof timeoutVar !== 'undefined') {
  	clearTimeout(timeoutVar);
  	delete timeoutVar;
  }
  else {
	console.log("No timeout variable");  
  }
  
  // Continue
  getElementById('ctl00_ctl00_cphMain_cphMacTool_DASHBOARDCLICKEDBOX').value = "Refresh";
  __doPostBack('ctl00$ctl00$cphMain$cphMacTool$CONTINUE','');
}

function CancelClick() {
  var a = event.clientX, b = event.clientY,
  elementMouseIsOver = document.elementFromPoint(a, b);
  var textboxInput = document.getElementsByName("ctl00$ctl00$cphMain$cphMacTool$TEXTBOX")[0];
  if (typeof textboxInput !== "undefined") {
	 // Clear the object value
	 textboxInput.value = "";
  }
  // Delete the cached Stage JSON Data
  window.localStorage.removeItem('stageData');
  
  // Delete timeout if exists
  if (typeof timeoutVar !== 'undefined') {
    clearTimeout(timeoutVar);
  	delete timeoutVar;
  }
  else {
	console.log("No timeout variable");  
  }
  
  // Continue
  getElementById('ctl00_ctl00_cphMain_cphMacTool_DASHBOARDCLICKEDBOX').value = "Cancel";
  __doPostBack('ctl00$ctl00$cphMain$cphMacTool$CONTINUE','');
}

function generateStageTable(list) {
	// Hardcode columns to preserve the order
	var cols = ["EVENTTIME", "STAGENAME", "EVENTNAME", "PARAM"];
	  
	// Create a table element
	var table = document.createElement("table");
	  
	// Create table row tr element of a table
	var tr = table.insertRow(-1);
	  
	for (var i = 0; i < cols.length; i++) {
		  
		// Create the table header th element
		var theader = document.createElement("th");
		theader.innerHTML = cols[i];
		  
		// Append columnName to the table row
		tr.appendChild(theader);
	}
	  
	// Adding the data to the table
	for (var i = 0; i < list.length; i++) {
		  
		// Create a new row
		trow = table.insertRow(-1);
		for (var j = 0; j < cols.length; j++) {
			var cell = trow.insertCell(-1);
			  
			// Inserting the cell at particular place
			cell.innerHTML = list[i][cols[j]];
		}
	}
	  
	// Add the newely created table containing json data
	var el = document.getElementById("table");
	el.innerHTML = "";
	el.appendChild(table);
}    

function gridSelection(x) {
	// Deselect any selected rows, and select the clicked row.
	var selectedRows = document.getElementsByClassName("selectedRow");
	for (i=0; i < selectedRows.length; i++) {
        var thisRow = selectedRows[i];
		thisRow.classList.remove("selectedRow");
		thisRow.classList.add("unselectedRow");
	}
	x.parentElement.classList.add("selectedRow");
	
	// Get the Process ID and convert the JSON from Local Session Storage
	var processId = x.parentElement.cells[0].innerHTML;
	var stageJson = window.localStorage.getItem('stageData');
	var stages = JSON.parse(stageJson);
	
	// Retrieve the stages for the selected Process ID
	var result = stages.filter(obj => {
	  return obj.PROCESSID == processId
	})
	var stageDetails = result[0].STAGEDETAILS;

	// Generate the table
	generateStageTable(stageDetails);
	
	// Add the Heading information
	var header = document.getElementById("stageDetailsTxt");
	header.innerText = x.parentElement.cells[1].innerHTML + " - " + x.parentElement.cells[2].innerHTML;
}

function launchedUiRefresh() {
	// Return to main UI gracefully
	// This is run when the Launch UI screen is loaded, and waits 30 seconds before executing a 'graceful timeout'
	try {
		
		// Delete timeout if exists
		if (typeof timeoutVar !== 'undefined') {
			clearTimeout(timeoutVar);
			delete timeoutVar;
		}
		
		// Continue (graceful timeout)
		getElementById('ctl00_ctl00_cphMain_cphMacTool_DASHBOARDCLICKEDBOX').value = "Refresh";
		__doPostBack('ctl00$ctl00$cphMain$cphMacTool$CONTINUE','');
	}
	catch {
		console.log('unable to refresh');
	}
}